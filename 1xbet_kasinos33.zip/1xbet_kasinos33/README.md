# 1xbet_kasinos33

Landing page promocional para TrustDice, BC.Game y 1xBet.

## 🚀 Cómo subir a GitHub

```bash
git clone https://github.com/ncolex/1xbet_kasinos33.git
cd 1xbet_kasinos33
cp -r /ruta/del/proyecto/* .
git add .
git commit -m "Primera versión funcional"
git push origin main
```

## 🌐 Deploy en Netlify

1. Ingresar a [https://app.netlify.com/](https://app.netlify.com/)
2. **New site from Git** → Seleccionar GitHub.
3. Elegir `ncolex/1xbet_kasinos33`.
4. Branch: **main**.
5. Build command: *(vacío)*.
6. Publish directory: `./`.
7. **Deploy site**.
